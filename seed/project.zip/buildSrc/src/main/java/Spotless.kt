object Spotless {
    const val spotlessGradle = "com.diffplug.spotless:spotless-plugin-gradle:5.15.0"
}
