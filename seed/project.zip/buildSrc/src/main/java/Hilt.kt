object Hilt {
    const val android = "com.google.dagger:hilt-android:2.42"
    const val compiler = "com.google.dagger:hilt-compiler:2.42"
}