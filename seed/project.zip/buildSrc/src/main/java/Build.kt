object Build {
    const val androidBuildTool = "com.android.tools.build:gradle:7.0.4"
    const val kotlinGradlePlugin = "org.jetbrains.kotlin:kotlin-gradle-plugin:1.7.0"
    const val hiltGradlePlugin = "com.google.dagger:hilt-android-gradle-plugin:2.38.1"
}