object DatePicker {
    const val spinnerDatePicker = "com.github.drawers:SpinnerDatePicker:2.0.1"
}