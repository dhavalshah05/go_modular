object Alert {
    const val alerter = "com.github.tapadoo:alerter:7.2.4"
}