object Testing {
    const val jUnit = "junit:junit:4.13.2"
    const val jUnitAndroidX = "androidx.test.ext:junit:1.1.4"
    const val espresso = "androidx.test.espresso:espresso-core:3.5.0"
}