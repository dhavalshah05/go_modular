object FragNav {
    const val fragNav = "com.ncapdevi:frag-nav:3.3.0"
}