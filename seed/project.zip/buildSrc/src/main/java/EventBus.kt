object EventBus {
    const val greenRobot = "org.greenrobot:eventbus:3.2.0"
}