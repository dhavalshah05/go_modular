object Navigation {
    private const val navVersion = "2.5.3"
    const val navFragment = "androidx.navigation:navigation-fragment-ktx:$navVersion"
    const val navUi = "androidx.navigation:navigation-ui-ktx:$navVersion"
}