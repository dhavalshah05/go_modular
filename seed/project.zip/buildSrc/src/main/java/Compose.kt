object Compose {
    const val composeVersion = "1.2.0"
    const val composeCompilerVersion = "1.2.0"
    const val material = "androidx.compose.material:material:1.2.0"
    const val uiTooling = "androidx.compose.ui:ui-tooling:1.2.0"
    const val uiToolingPreview = "androidx.compose.ui:ui-tooling-preview:1.2.0"
}