object Material {
    const val material = "com.google.android.material:material:1.5.0"
}