object ProjectConfig {
    const val applicationId = "com.androidstarter.app"

    const val compileSdk = 32
    const val minSdk = 23
    const val targetSdk = 31

    const val versionCode = 1
    const val versionName = "1.0"
}