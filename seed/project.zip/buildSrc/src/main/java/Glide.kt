object Glide {
    const val glide = "com.github.bumptech.glide:glide:4.13.0"
    const val compiler = "com.github.bumptech.glide:compiler:4.12.0"
}