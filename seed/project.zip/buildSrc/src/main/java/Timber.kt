object Timber {
    const val timber = "com.jakewharton.timber:timber:5.0.1"
}