object Retrofit {
    const val retrofit = "com.squareup.retrofit2:retrofit:2.9.0"
    const val gsonConvertor = "com.squareup.retrofit2:converter-gson:2.9.0"
    const val logging = "com.squareup.okhttp3:logging-interceptor:4.9.3"
}