object AndroidX {
    const val coreKtx = "androidx.core:core-ktx:1.7.0"
    const val appCompat = "androidx.appcompat:appcompat:1.4.1"
    const val constraintLayout = "androidx.constraintlayout:constraintlayout:2.1.3"
    const val activityKtx = "androidx.activity:activity-ktx:1.4.0"
}