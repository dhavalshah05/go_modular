package com.app.navigator

import androidx.fragment.app.FragmentManager
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import com.app.R
import com.service.navigation.Navigator

class AppNavigator constructor(
    private val fragmentManager: FragmentManager
) : Navigator {

    private val navController: NavController
        get() {
            val navHostFragment = fragmentManager.findFragmentById(R.id.navHostFragment) as NavHostFragment
            return navHostFragment.navController
        }

    override fun openSplashScreen() {
        navController.navigate(R.id.splashFragment)
    }

    override fun openUserOnBoardingScreen() {
        navController.navigate(R.id.onBoardingFragment)
    }
}