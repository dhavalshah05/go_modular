package com.service.navigation

interface Navigator {
    fun openSplashScreen()
    fun openUserOnBoardingScreen()
}