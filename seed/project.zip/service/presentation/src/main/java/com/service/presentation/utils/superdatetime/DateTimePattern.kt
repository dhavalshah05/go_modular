package com.service.presentation.utils.superdatetime

interface DateTimePattern {
    fun getPattern(): String
}